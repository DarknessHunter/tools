#!/usr/bin/python

import sys
import os
import ftplib
import ConfigParser
import urllib
import gzip
import csv


# Reading configuration file...
config = ConfigParser.ConfigParser()
config.read('dic.cfg')

years = config.get('years', 'years').split(',')
chars = config.get('specialchars', 'chars').split(',')

numfrom = config.getint('nums','from')
numto = config.getint('nums','to')

wcfrom = config.getint('nums','wcfrom')
wcto = config.getint('nums','wcto')

threshold = config.getint('nums','threshold')

# 1337 mode configs, well you can add more lines if you add it to config file too.
# You will need to add more lines in two places in cupp.py code as well...

i = config.get('leet','i')

# for concatenations...

def concats(seq, start, stop):
	for mystr in seq:
		for num in xrange(start, stop):
			yield mystr + str(num)


# for sorting and making combinations...

def komb(seq, start, special = ""):
	for mystr in seq:
		for mystr1 in start:
			yield mystr + special + mystr1

# print list to file counting words

def print_to_file(filename, unique_list_finished):
	f = open ( filename, 'w' )
	unique_list_finished.sort()
	f.write (os.linesep.join(unique_list_finished))
	f = open ( filename, 'r' )
	lines = 0
	for line in f:
		lines += 1
	f.close()
	print "[+] Saving dictionary to \033[1;31m"+filename+"\033[1;m, counting \033[1;31m"+str(lines)+" words.\033[1;m"
	print "[+] Now load your pistolero with \033[1;31m"+filename+"\033[1;m and shoot! Good luck!"

if len(sys.argv) < 2 or sys.argv[1] == '-h ':
	print "	[ Options ]\r\n"
	print "	-h	You are looking at it bitch! :)"

	print "	-i	Interactive questions for user password profiling\r\n"
	exit()
elif sys.argv[1] == '-i':
	print "\r\n[+] Insert the informations about the victim to make a dictionary"
	print "[+] If you don't know all the info, just hit enter when asked! ;)\r\n"

# We need some informations first!

	name = raw_input("> First Name: ").lower()
	while len(name) == 0 or name == " " or name == "  " or name == "   ":
		print "\r\n[-] You must enter a name at least!"
		name = raw_input("> Name: ").lower()
	name = str(name)

	surname = raw_input("> Surname: ").lower()
	nick = raw_input("> Nickname: ").lower()
	birthdate = raw_input("> Birthdate (DDMMYYYY): ")
	while len(birthdate) != 0 and len(birthdate) != 8:
		print "\r\n[-] You must enter 8 digits for birthday!"
		birthdate = raw_input("> Birthdate (DDMMYYYY): ")
	birthdate = str(birthdate)

	print "\r\n"

	wife = raw_input("> Partners) name: ").lower()
	wifen = raw_input("> Partners) nickname: ").lower()
	wifeb = raw_input("> Partners) birthdate (DDMMYYYY): ")
	while len(wifeb) != 0 and len(wifeb) != 8:
		print "\r\n[-] You must enter 8 digits for birthday!"
		wifeb = raw_input("> Partners birthdate (DDMMYYYY): ")
	wifeb = str(wifeb)
	print "\r\n"

	kid = raw_input("> Child's name: ").lower()
	kidn = raw_input("> Child's nickname: ").lower()
	kidb = raw_input("> Child's birthdate (DDMMYYYY): ")
	while len(kidb) != 0 and len(kidb) != 8:
		print "\r\n[-] You must enter 8 digits for birthday!"
		kidb = raw_input("> Child's birthdate (DDMMYYYY): ")
	kidb = str(kidb)
	print "\r\n"

	pet = raw_input("> Pet's name: ").lower()
	company = raw_input("> Company name: ").lower()
	print "\r\n"

	words = ['']
	words1 = raw_input("> Do you want to add some key words about the victim? Y/[N]: ").lower()
	words2 = ""
	if words1 == "y":
		words2 = raw_input("> Please enter the words, separated by comma. [i.e. hacker,juice,black], spaces will be removed: ").replace(" ","")
	words = words2.split(",")

	spechars = ['']
	spechars1 = raw_input("> Do you want to add special chars at the end of words? Y/[N]: ").lower()
	if spechars1 == "y":
		for spec1 in chars:
			spechars.append(spec1)
			for spec2 in chars:
				spechars.append(spec1+spec2)
				for spec3 in chars:
					spechars.append(spec1+spec2+spec3)

	randnum = raw_input("> Do you want to add some random numbers at the end of words? Y/[N]:").lower()
	leetmode = raw_input("> Leet mode? (i.e. leet = 1337) Y/[N]: ").lower()


	print "\r\n[+] Now making a dictionary..."


# Now me must do some string modifications...

# Birthdays first

	birthdate_yy = birthdate[-2:]
	birthdate_yyy = birthdate[-3:]
	birthdate_yyyy = birthdate[-4:]
	birthdate_xd = birthdate[1:2]
	birthdate_xm = birthdate[3:4]
	birthdate_dd = birthdate[:2]
	birthdate_mm = birthdate[2:4]

	wifeb_yy = wifeb[-2:]
	wifeb_yyy = wifeb[-3:]
	wifeb_yyyy = wifeb[-4:]
	wifeb_xd = wifeb[1:2]
	wifeb_xm = wifeb[3:4]
	wifeb_dd = wifeb[:2]
	wifeb_mm = wifeb[2:4]

	kidb_yy = kidb[-2:]
	kidb_yyy = kidb[-3:]
	kidb_yyyy = kidb[-4:]
	kidb_xd = kidb[1:2]
	kidb_xm = kidb[3:4]
	kidb_dd = kidb[:2]
	kidb_mm = kidb[2:4]


	# Convert first letters to uppercase...

	nameup = name.title()
	surnameup = surname.title()
	nickup = nick.title()
	wifeup = wife.title()
	wifenup = wifen.title()
	kidup = kid.title()
	kidnup = kidn.title()
	petup = pet.title()
	companyup = company.title()

	wordsup = []
	wordsup = map(str.title, words)

	word = words+wordsup

	# reverse a name

	rev_name = name[::-1]
	rev_nameup = nameup[::-1]
	rev_nick = nick[::-1]
	rev_nickup = nickup[::-1]
	rev_wife = wife[::-1]
	rev_wifeup = wifeup[::-1]
	rev_kid = kid[::-1]
	rev_kidup = kidup[::-1]

	reverse = [rev_name, rev_nameup, rev_nick, rev_nickup, rev_wife, rev_wifeup, rev_kid, rev_kidup]
	rev_n = [rev_name, rev_nameup, rev_nick, rev_nickup]
	rev_w = [rev_wife, rev_wifeup]
	rev_k = [rev_kid, rev_kidup]
	# Let's do some serious work! This will be a mess of code, but... who cares? :)

	# Birthdays combinations

	bds = [birthdate_yy, birthdate_yyy, birthdate_yyyy, birthdate_xd, birthdate_xm, birthdate_dd, birthdate_mm]

	bdss = []

	for bds1 in bds:
		bdss.append(bds1)
		for bds2 in bds:
			if bds.index(bds1) != bds.index(bds2):
				bdss.append(bds1+bds2)
				for bds3 in bds:
					if bds.index(bds1) != bds.index(bds2) and bds.index(bds2) != bds.index(bds3) and bds.index(bds1) != bds.index(bds3):
						bdss.append(bds1+bds2+bds3)



	# For a woman...
	wbds = [wifeb_yy, wifeb_yyy, wifeb_yyyy, wifeb_xd, wifeb_xm, wifeb_dd, wifeb_mm]

	wbdss = []

	for wbds1 in wbds:
		wbdss.append(wbds1)
		for wbds2 in wbds:
			if wbds.index(wbds1) != wbds.index(wbds2):
				wbdss.append(wbds1+wbds2)
				for wbds3 in wbds:
					if wbds.index(wbds1) != wbds.index(wbds2) and wbds.index(wbds2) != wbds.index(wbds3) and wbds.index(wbds1) != wbds.index(wbds3):
						wbdss.append(wbds1+wbds2+wbds3)



	# and a child...
	kbds = [kidb_yy, kidb_yyy, kidb_yyyy, kidb_xd, kidb_xm, kidb_dd, kidb_mm]

	kbdss = []

	for kbds1 in kbds:
		kbdss.append(kbds1)
		for kbds2 in kbds:
			if kbds.index(kbds1) != kbds.index(kbds2):
				kbdss.append(kbds1+kbds2)
				for kbds3 in kbds:
					if kbds.index(kbds1) != kbds.index(kbds2) and kbds.index(kbds2) != kbds.index(kbds3) and kbds.index(kbds1) != kbds.index(kbds3):
						kbdss.append(kbds1+kbds2+kbds3)

	# string combinations....

	kombinaac = [pet, petup, company, companyup]

	kombina = [name, surname, nick, nameup, surnameup, nickup]

	kombinaw = [wife, wifen, wifeup, wifenup, surname, surnameup]

	kombinak = [kid, kidn, kidup, kidnup, surname, surnameup]

	kombinaa = []
	for kombina1 in kombina:
		kombinaa.append(kombina1)
		for kombina2 in kombina:
			if kombina.index(kombina1) != kombina.index(kombina2) and kombina.index(kombina1.title()) != kombina.index(kombina2.title()):
				kombinaa.append(kombina1+kombina2)

	kombinaaw = []
	for kombina1 in kombinaw:
		kombinaaw.append(kombina1)
		for kombina2 in kombinaw:
			if kombinaw.index(kombina1) != kombinaw.index(kombina2) and kombinaw.index(kombina1.title()) != kombinaw.index(kombina2.title()):
				kombinaaw.append(kombina1+kombina2)

	kombinaak = []
	for kombina1 in kombinak:
		kombinaak.append(kombina1)
		for kombina2 in kombinak:
			if kombinak.index(kombina1) != kombinak.index(kombina2) and kombinak.index(kombina1.title()) != kombinak.index(kombina2.title()):
				kombinaak.append(kombina1+kombina2)



	komb1 = list(komb(kombinaa, bdss))
	komb1 += list(komb(kombinaa, bdss, "_"))
	komb2 = list(komb(kombinaaw, wbdss))
	komb2 += list(komb(kombinaaw, wbdss, "_"))
	komb3 = list(komb(kombinaak, kbdss))
	komb3 += list(komb(kombinaak, kbdss, "_"))
	komb4 = list(komb(kombinaa, years))
	komb4 += list(komb(kombinaa, years, "_"))
	komb5 = list(komb(kombinaac, years))
	komb5 += list(komb(kombinaac, years, "_"))
	komb6 = list(komb(kombinaaw, years))
	komb6 += list(komb(kombinaaw, years, "_"))
	komb7 = list(komb(kombinaak, years))
	komb7 += list(komb(kombinaak, years, "_"))
	komb8 = list(komb(word, bdss))
	komb8 += list(komb(word, bdss, "_"))
	komb9 = list(komb(word, wbdss))
	komb9 += list(komb(word, wbdss, "_"))
	komb10 = list(komb(word, kbdss))
	komb10 += list(komb(word, kbdss, "_"))
	komb11 = list(komb(word, years))
	komb11 += list(komb(word, years, "_"))
	komb12 = ['']
	komb13 = ['']
	komb14 = ['']
	komb15 = ['']
	komb16 = ['']
	komb21 = ['']
	if randnum == "y":
		komb12 = list(concats(word, numfrom, numto))
		komb13 = list(concats(kombinaa, numfrom, numto))
		komb14 = list(concats(kombinaac, numfrom, numto))
		komb15 = list(concats(kombinaaw, numfrom, numto))
		komb16 = list(concats(kombinaak, numfrom, numto))
		komb21 = list(concats(reverse, numfrom, numto))
	komb17 = list(komb(reverse, years))
	komb17 += list(komb(reverse, years, "_"))
	komb18 = list(komb(rev_w, wbdss))
	komb18 += list(komb(rev_w, wbdss, "_"))
	komb19 = list(komb(rev_k, kbdss))
	komb19 += list(komb(rev_k, kbdss, "_"))
	komb20 = list(komb(rev_n, bdss))
	komb20 += list(komb(rev_n, bdss, "_"))
	komb001 = ['']
	komb002 = ['']
	komb003 = ['']
	komb004 = ['']
	komb005 = ['']
	komb006 = ['']
	if spechars1 == "y":
		komb001 = list(komb(kombinaa, spechars))
		komb002 = list(komb(kombinaac, spechars))
		komb003 = list(komb(kombinaaw , spechars))
		komb004 = list(komb(kombinaak , spechars))
		komb005 = list(komb(word, spechars))
		komb006 = list(komb(reverse, spechars))

	print "[+] Sorting list and removing duplicates..."

	komb_unique1 = dict.fromkeys(komb1).keys()
	komb_unique2 = dict.fromkeys(komb2).keys()
	komb_unique3 = dict.fromkeys(komb3).keys()
	komb_unique4 = dict.fromkeys(komb4).keys()
	komb_unique5 = dict.fromkeys(komb5).keys()
	komb_unique6 = dict.fromkeys(komb6).keys()
	komb_unique7 = dict.fromkeys(komb7).keys()
	komb_unique8 = dict.fromkeys(komb8).keys()
	komb_unique9 = dict.fromkeys(komb9).keys()
	komb_unique10 = dict.fromkeys(komb10).keys()
	komb_unique11 = dict.fromkeys(komb11).keys()
	komb_unique12 = dict.fromkeys(komb12).keys()
	komb_unique13 = dict.fromkeys(komb13).keys()
	komb_unique14 = dict.fromkeys(komb14).keys()
	komb_unique15 = dict.fromkeys(komb15).keys()
	komb_unique16 = dict.fromkeys(komb16).keys()
	komb_unique17 = dict.fromkeys(komb17).keys()
	komb_unique18 = dict.fromkeys(komb18).keys()
	komb_unique19 = dict.fromkeys(komb19).keys()
	komb_unique20 = dict.fromkeys(komb20).keys()
	komb_unique21 = dict.fromkeys(komb21).keys()
	komb_unique01 = dict.fromkeys(kombinaa).keys()
	komb_unique02 = dict.fromkeys(kombinaac).keys()
	komb_unique03 = dict.fromkeys(kombinaaw).keys()
	komb_unique04 = dict.fromkeys(kombinaak).keys()
	komb_unique05 = dict.fromkeys(word).keys()
	komb_unique07 = dict.fromkeys(komb001).keys()
	komb_unique08 = dict.fromkeys(komb002).keys()
	komb_unique09 = dict.fromkeys(komb003).keys()
	komb_unique010 = dict.fromkeys(komb004).keys()
	komb_unique011 = dict.fromkeys(komb005).keys()
	komb_unique012 = dict.fromkeys(komb006).keys()

	uniqlist = bdss+wbdss+kbdss+reverse+komb_unique01+komb_unique02+komb_unique03+komb_unique04+komb_unique05+komb_unique1+komb_unique2+komb_unique3+komb_unique4+komb_unique5+komb_unique6+komb_unique7+komb_unique8+komb_unique9+komb_unique10+komb_unique11+komb_unique12+komb_unique13+komb_unique14+komb_unique15+komb_unique16+komb_unique17+komb_unique18+komb_unique19+komb_unique20+komb_unique21+komb_unique07+komb_unique08+komb_unique09+komb_unique010+komb_unique011+komb_unique012

	unique_lista = dict.fromkeys(uniqlist).keys()
	unique_leet = []
	if leetmode == "y":
		for x in unique_lista: # if you want to add more leet chars, you will need to add more lines in cupp.cfg too...
			x = x.replace('a',a)
			x = x.replace('i',i)
			x = x.replace('e',e)
			x = x.replace('t',t)
			x = x.replace('o',o)
			x = x.replace('s',s)
			x = x.replace('g',g)
			x = x.replace('z',z)
			unique_leet.append(x)

	unique_list = unique_lista + unique_leet

	unique_list_finished = []
	unique_list_finished = [x for x in unique_list if len(x) < wcto and len(x) > wcfrom]

	print_to_file(name+'.txt', unique_list_finished)
	exit()


elif sys.argv[1] == '-a':
	url = config.get('alecto','alectourl')

	print "\r\n[+] Checking if alectodb is not present..."
	if os.path.isfile('alectodb.csv.gz') == 0:
		print "[+] Downloading alectodb.csv.gz..."
		webFile = urllib.urlopen(url)
		localFile = open(url.split('/')[-1], 'w')
		localFile.write(webFile.read())
		webFile.close()
		localFile.close()


	f = gzip.open('alectodb.csv.gz', 'rb')

	data = csv.reader(f)

	usernames = []
	passwords = []
	for row in data:
		usernames.append(row[5])
		passwords.append(row[6])
	gus = list(set(usernames))
	gpa = list(set(passwords))
	gus.sort()
	gpa.sort()

	print "\r\n[+] Exporting to alectodb-usernames.txt and alectodb-passwords.txt\r\n[+] Done."
	f = open ( 'alectodb-usernames.txt', 'w' )
	f.write (os.linesep.join(gus))
	f.close()

	f = open ( 'alectodb-passwords.txt', 'w' )
	f.write (os.linesep.join(gpa))
	f.close()


	f.close()
	sys.exit()
